#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# CREATED:2015-03-02 11:50:46 by Brian McFee <brian.mcfee@nyu.edu>
'''A python wrapper for rubberband'''

from .version import version as __version__
from .pyrb import *
