#!/usr/bin/env python
# -*- encoding: utf-8 -*-

version = '0.4.0'
